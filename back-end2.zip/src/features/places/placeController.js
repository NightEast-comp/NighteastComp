// File: src/features/places/placeRoutes.js
const express = require('express');
const router = express.Router();
const placeController = require('./placeController'); // Pastikan path-nya sesuai dengan lokasi file

// Route untuk mengambil semua tempat wisata
router.get('/', placeController.getAllPlaces);

// Route untuk mengambil detail satu tempat berdasarkan ID
router.get('/:id', placeController.getPlaceById);

// Route untuk menambahkan tempat wisata baru
router.post('/', placeController.createPlace);

// Route untuk memperbarui data tempat wisata
router.put('/:id', placeController.updatePlace);

// Route untuk menghapus tempat wisata
router.delete('/:id', placeController.deletePlace);

module.exports = router;
