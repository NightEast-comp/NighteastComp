const express = require('express');
const router = express.Router();

// Pastikan path impor model dan controller sesuai dengan lokasi file baru.
// Misalnya, model admin dan fungsi login berada di fitur admin.
const Admin = require('../../features/admin/adminModel');  
const { loginAdmin } = require('../../features/admin/adminController');

// Route untuk register (opsional)
router.post('/register', async (req, res) => {
  try {
    // Contoh logika register
    const { username, password } = req.body;
    // Logika pembuatan admin baru (misal: simpan ke database)
    // ... kode register admin
    res.status(201).json({ message: 'Admin registered successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Registration failed', error });
  }
});

// Route untuk login menggunakan controller loginAdmin
router.post('/login', loginAdmin);

module.exports = router;
